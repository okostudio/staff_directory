let staff = {};
let staffMembers;




const init = () => {
  staffMembers = document.querySelector('.staff-members');

  $.getJSON('http://staff.loc/wp-json/wp/v2/posts/', function(data) {
    console.log(data)


    staff = data.map( staff_member => staff_member );

    staff.sort( (a,b) => {
      if(a.first_name < b.first_name) return -1;
      if(a.first_name > b.first_name) return 1;
      return 0;
    } )

    staff.map( (staff_member) => {
      let p1 = new StaffMember(staff_member.photo);
      /*
      var html = 
      
        `<div class="staff-member">
                    
          <div class="photo-holder">
            <div class="photo" style="background-image: url( ${staff_member.photo} );"></div>
            <!--<div class="wedge"></div>-->
          </div>
          
          <div class="bio">
            <h2>${staff_member.first_name} ${staff_member.last_name}</h2>
            <h3>${staff_member.job_title}</h3>
            
            <p class="label">Come to me for help with:</p>
            <p class="small">${staff_member.can_help_with}</p>
          </div>
    
        </div>`

      $(html).appendTo('.staff-members');
      */
    })

  });
}




$(document).ready(init)