			</div>
		</div>
		<footer class="site-footer" role="contentinfo">
			<p>Footer goes here</p>			
		</footer><!-- #colophon -->
	</div>
</body>
